
(function (){
    // sons
    var finalizarSom    = document.getElementById('sonFinalizar');
    var confirmar       = document.getElementById('confirmar');  

    window.addEventListener('load', function(){        
        finalizarSom.play();
    });
   
})()